'use client'

import Image from 'next/image'
import {
  ArrowLeft,
  ArrowUpLeft,
  CalendarDays,
  Camera,
  ChevronLeft,
  CirclePlay,
  Clock3,
  Globe2,
  Menu,
  MessageSquareText,
  Play,
  Radio,
  Send,
  UserRound,
} from 'lucide-react'
import { useRef, useState, type ChangeEvent, type FormEvent } from 'react'

type Story = {
  category: string
  title: string
  summary: string
  date: string
  image: string
  alt: string
}

const initialStories: Story[] = [
  {
    category: 'مصر والسعودية',
    title: 'البرلمان المصري يوافق على تفويض الرئيس السيسي لدعم السعودية عسكريًا',
    summary:
      'أعلن مجلس النواب موافقته على تفويض الرئيس عبد الفتاح السيسي لاتخاذ ما يلزم من إجراءات لدعم المملكة العربية السعودية، في ظل تصاعد التوترات الإقليمية. وجاء القرار عقب تأكيد الرئيس ضرورة مساندة المملكة وشعبها والدفاع عن أراضيها، في إطار الشراكة المصرية السعودية وحماية الأمن القومي العربي.',
    date: '٢٨ أكتوبر ٢٠٢٦',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-10-27%20at%203.33.30%20PM-fgr4TnV7RTrXWpQTMscje47TcTUnTD.jpeg',
    alt: 'الرئيس المصري عبد الفتاح السيسي وولي العهد السعودي خلال لقاء رسمي',
  },
  {
    category: 'مجلس النواب',
    title: 'جلسة برئاسة هشام بدوي وتصويت بالنداء بالاسم',
    summary:
      'عُقدت الجلسة برئاسة المستشار هشام بدوي في مقر البرلمان الجديد بالعاصمة الإدارية الجديدة. وسبقها عقد ثلاث جلسات سرية في أيام ١٨ و١٩ و٢٦ أكتوبر لمناقشة التطورات الإقليمية. وأُجري التصويت بالنداء بالاسم على النواب لضمان استيفاء الإجراءات والشروط الدستورية.',
    date: '٢٨ أكتوبر ٢٠٢٦',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-10-27%20at%203.45.53%20PM%20%281%29-y2D2CBxo9lzi2ow0r2w9JOPzyHUiag.jpeg',
    alt: 'أعضاء مجلس النواب في جلسة رسمية داخل القاعة',
  },
  {
    category: 'قراءة دستورية',
    title: 'المادة ١٥٢ ترسم ضوابط مشاركة القوات المسلحة خارج الحدود',
    summary:
      'يستند القرار إلى المادة ١٥٢ من الدستور المصري، التي تشترط موافقة ثلثي أعضاء مجلس النواب وأخذ رأي مجلس الدفاع الوطني قبل إرسال قوات مسلحة في مهمة قتالية خارج حدود الدولة. وأكدت البيانات المتداولة أن أي تحرك محتمل سيكون دفاعيًا ومساندًا، وأن التفويض لا يعني بالضرورة نقل قوات أو بدء عمليات عسكرية فورًا. وتظل التطورات الرسمية اللاحقة هي المحدد لطبيعة أي خطوة، وسط مخاوف من اتساع الصراع وانعكاساته على البحر الأحمر وقناة السويس.',
    date: '٢٨ أكتوبر ٢٠٢٦',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-10-27%20at%203.45.53%20PM-ikvvb6Ot9BwQPv3bDFAx2JAtGeRZhN.jpeg',
    alt: 'رئيس مجلس النواب يتحدث من منصة البرلمان خلال جلسة',
  },
]

const videos = [
  {
    category: 'فيديو الخبر | YouTube',
    title: 'البرلمان المصري يوافق على تفويض الرئيس السيسي لدعم السعودية عسكريًا',
    summary: 'شاهد الفيديو المرفق مع التغطية، ثم تابع تفاصيل القرار وخلفيته الدستورية في التقرير.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-10-27%20at%205.29.30%20PM-zOblfqTCSJGJGyoCKTqMyVzGPCzaxz.jpeg',
    alt: 'لقطة واسعة لأعضاء البرلمان داخل القاعة',
  },
  {
    category: 'المصدر: YouTube',
    title: 'رابط المصدر المصوّر للخبر',
    summary: 'المصدر المرفق من YouTube للاطلاع على المادة المصوّرة ذات الصلة بالتغطية.',
    image: undefined,
    alt: undefined,
  },
]

const latestHeadlines = [
  'مجلس النواب يوافق على تفويض الرئيس لدعم السعودية',
  'المنتخب يستعد لمواجهته المقبلة وسط ترقب جماهيري',
  'قافلة طبية لمجلس الوزراء تقدم خدماتها في أسوان',
  'تطورات جديدة في انتخابات إسرائيل بعد فرز الأصوات',
]

const mostReadHeadlines = [
  'خلفية القرار البرلماني وضوابط المادة ١٥٢',
  'إخلاء سبيل طالب في واقعة صور مدرسين',
  'متابعة أخبار المنتخب ومباريات الكرة',
]

type SidebarStory = {
  category: string
  title: string
  summary: string
  image: string
  alt: string
}

const initialSidebarStories: SidebarStory[] = [
  {
    category: 'عرب وعالم',
    title: 'نتنياهو ٥٣ مقعدًا بعد فرز ١٠٠٪ من الأصوات',
    summary: 'بحسب الأرقام الواردة في الصورة المرفقة، سجل الليكود ٤٨ مقعدًا والقوائم العربية ١٩ مقعدًا.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Yiru5dW1w9hqKuILB9K1a1mg4sEyeO.png',
    alt: 'صورة سياسية مرافقة لخبر عن نتائج الانتخابات الإسرائيلية',
  },
  {
    category: 'حوادث وقضايا',
    title: 'إخلاء سبيل طالب في اتهامه بفبركة صور مدرسين',
    summary: 'قرار بإخلاء سبيل طالب متهم بفبركة صور لمدرسين ونشرها بقصد الإساءة إليهما.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-crks42EYGDRnjZPTBMvErP271iugq0.png',
    alt: 'مطرقة قاضٍ ترمز إلى خبر قضائي',
  },
  {
    category: 'محافظات',
    title: 'الكشف على ٩٥٠ حالة ضمن قافلة أسوان الطبية',
    summary: 'وفقًا للصورة المرفقة، شملت القافلة الطبية لمجلس الوزراء بمحافظة أسوان الكشف على ٩٥٠ حالة.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-vYuTPhk59vXj0ssTKDsnl3jpDlUyUD.png',
    alt: 'فريق طبي ومرافقون في صورة مرتبطة بقافلة طبية في أسوان',
  },
  {
    category: 'رياضة',
    title: 'المنتخب الوطني يواصل استعداداته للمواجهة المقبلة',
    summary: 'ترقب جماهيري لمباراة المنتخب، ومتابعة آخر الاستعدادات قبل صافرة البداية.',
    image: '/egypt-football-news.png',
    alt: 'لقطة رياضية من مباراة كرة قدم ليلية في استاد مصري',
  },
]

function formatArabicIndex(index: number) {
  return new Intl.NumberFormat('ar-EG', { useGrouping: false }).format(index + 1).padStart(2, '٠')
}

function Editable({
  as: Tag = 'span',
  children,
  className,
  label,
}: {
  as?: 'span' | 'p' | 'h1' | 'h2' | 'h3' | 'strong'
  children: string
  className?: string
  label: string
}) {
  return (
    <Tag
      className={className}
      contentEditable
      suppressContentEditableWarning
      aria-label={`${label} — قابل للتحرير`}
      title="اضغط لتحرير النص"
    >
      {children}
    </Tag>
  )
}

function SectionHeading({
  kicker,
  title,
  id,
}: {
  kicker?: string
  title: string
  id?: string
}) {
  return (
    <div className="section-heading" id={id}>
      <div>
        {kicker && <span className="section-kicker">{kicker}</span>}
        <h2>{title}</h2>
      </div>
      <span className="section-heading-rule" aria-hidden="true" />
    </div>
  )
}

function AdCreative({
  variant,
  initialImage,
  imageAlt,
  label,
}: {
  variant: 'sidebar' | 'banner'
  initialImage: string
  imageAlt: string
  label: string
}) {
  const [image, setImage] = useState(initialImage)

  function handleUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (file) setImage(URL.createObjectURL(file))
  }

  return (
    <aside className={`ad-creative ad-creative--${variant}`} aria-label="إعلان">
      <span className="ad-creative-label" contentEditable suppressContentEditableWarning>إعلان</span>
      <label className="ad-creative-image" title="اضغط لتغيير صورة الإعلان">
        <Image src={image} alt={variant === 'banner' ? `${imageAlt}. Best Gadgets. Hot Deals. Shop Now.` : imageAlt} fill sizes={variant === 'sidebar' ? '280px' : '100vw'} unoptimized />
        {variant === 'banner' && (
          <span className="ad-creative-banner-copy">
            <span className="ad-creative-banner-title">Best Gadgets</span>
            <span className="ad-creative-banner-subtitle">Hot Deals</span>
            <span className="ad-creative-banner-description">Latest gadgets to make life easier. Discover everyday essentials and great deals.</span>
            <span className="ad-creative-banner-button">Shop Now</span>
          </span>
        )}
        <input className="visually-hidden" type="file" accept="image/*" aria-label={`تغيير صورة الإعلان: ${label}`} onChange={handleUpload} />
        <span className="ad-creative-edit">تغيير صورة الإعلان</span>
      </label>

    </aside>
  )
}

function StoryImage({ 
  story,
  index,
  onUpload,
}: {
  story: Story
  index: number
  onUpload: (index: number, event: ChangeEvent<HTMLInputElement>) => void
}) {
  const inputRef = useRef<HTMLInputElement>(null)

  return (
    <div className="story-image-wrap">
      <button
        type="button"
        className="story-image-button"
        onClick={() => inputRef.current?.click()}
        aria-label={`استبدال صورة الخبر ${index + 1}`}
      >
        <Image src={story.image} alt={story.alt} fill sizes="(max-width: 800px) 40vw, 340px" unoptimized />
        <span className="image-edit-hint">تغيير الصورة</span>
      </button>
      <input
        ref={inputRef}
        className="visually-hidden"
        type="file"
        accept="image/*"
        aria-label={`اختيار صورة الخبر ${index + 1}`}
        onChange={(event) => onUpload(index, event)}
      />
    </div>
  )
}

function NewsStory({
  story,
  index,
  onUpload,
}: {
  story: Story
  index: number
  onUpload: (index: number, event: ChangeEvent<HTMLInputElement>) => void
}) {
  return (
    <article className={`news-story ${index % 2 === 1 ? 'news-story--reverse' : ''}`}>
      <StoryImage story={story} index={index} onUpload={onUpload} />
      <div className="story-copy">
        <span className="story-category" contentEditable suppressContentEditableWarning>{story.category}</span>
        <Editable as="h3" className="story-title" label="عنوان الخبر">
          {story.title}
        </Editable>
        <Editable as="p" className="story-summary" label="ملخص الخبر">
          {story.summary}
        </Editable>
        <div className="story-meta">
          <span className="story-date">
            <CalendarDays aria-hidden="true" />
            <Editable label="تاريخ النشر">{story.date}</Editable>
          </span>
        </div>
      </div>
    </article>
  )
}

function InlineVideoSection({
  index,
  videoLink,
  onLinkChange,
}: {
  index: number
  videoLink: string
  onLinkChange: (index: number, value: string) => void
}) {
  const title = index === 0 ? 'فيديو الخبر' : 'فيديو إضافي'

  return (
    <section className="video-section video-section--inline" id={index === 0 ? 'videos' : undefined} aria-label={title}>
      <SectionHeading kicker={index === 0 ? 'شاهد بعد الخبر الأول' : 'تابع بقية التغطية'} title={title} />
      <div className="video-list">
        <VideoStory video={videos[index]} index={index} videoLink={videoLink} onLinkChange={onLinkChange} />
      </div>
    </section>
  )
}

function VideoStory({
  video,
  index,
  videoLink,
  onLinkChange,
}: {
  video: (typeof videos)[number]
  index: number
  videoLink: string
  onLinkChange: (index: number, value: string) => void
}) {
  const inputId = `video-link-${index + 1}`
  const safeLink = /^https?:\/\//i.test(videoLink) ? videoLink : undefined

  return (
    <article className={`video-story ${index % 2 === 1 ? 'video-story--reverse' : ''}`}>
      <div className="video-frame">
        <div className={`video-art video-art--${index + 1}`} aria-hidden="true">
          {video.image && (
            <Image src={video.image} alt={video.alt ?? ''} fill sizes="(max-width: 800px) 40vw, 340px" unoptimized className="video-poster" />
          )}
          <span className="video-art-mark">من قلب الحدث</span>
          <span className="video-art-line" />
          <span className="video-art-caption">صورة الفيديو</span>
        </div>
        {safeLink ? (
          <a className="video-play" href={safeLink} target="_blank" rel="noreferrer" aria-label="تشغيل الفيديو">
            <Play fill="currentColor" aria-hidden="true" />
          </a>
        ) : (
          <span className="video-play" aria-label="أضف رابط الفيديو لتشغيله">
            <Play fill="currentColor" aria-hidden="true" />
          </span>
        )}
        <span className="video-duration">فيديو</span>
      </div>
      <div className="video-copy">
        <span className="story-category" contentEditable suppressContentEditableWarning>{video.category}</span>
        <Editable as="h3" className="video-title" label="عنوان الفيديو">
          {video.title}
        </Editable>
        <Editable as="p" className="story-summary" label="وصف الفيديو">
          {video.summary}
        </Editable>
          <label className="video-link-field" htmlFor={inputId}>
            <span>{index === 1 ? 'المصدر: YouTube' : 'رابط الفيديو على YouTube'}</span>
            <input
            id={inputId}
            type="url"
            inputMode="url"
            placeholder="https://…"
            value={videoLink}
            onChange={(event) => onLinkChange(index, event.target.value)}
          />
        </label>
      </div>
    </article>
  )
}

function SidebarNewsCard({
  story,
  index,
  onUpload,
}: {
  story: SidebarStory
  index: number
  onUpload: (index: number, event: ChangeEvent<HTMLInputElement>) => void
}) {
  return (
    <article className="sidebar-news-card">
      <label className="sidebar-news-image" title="اضغط لتغيير صورة الخبر">
        <Image src={story.image} alt={story.alt} fill sizes="96px" unoptimized />
        <input className="visually-hidden" type="file" accept="image/*" aria-label={`تغيير صورة الخبر الجانبي ${index + 1}`} onChange={(event) => onUpload(index, event)} />
        <span className="sidebar-image-edit">تغيير</span>
      </label>
      <div className="sidebar-news-copy">
        <span className="story-category" contentEditable suppressContentEditableWarning>{story.category}</span>
        <Editable as="h3" className="sidebar-news-title" label="عنوان الخبر الجانبي">{story.title}</Editable>
        <Editable as="p" className="sidebar-news-summary" label="ملخص الخبر الجانبي">{story.summary}</Editable>
      </div>
    </article>
  )
}

function NewsSidebar() {
  const [stories, setStories] = useState(initialSidebarStories)

  function handleUpload(index: number, event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    const image = URL.createObjectURL(file)
    setStories((current) => current.map((story, storyIndex) => storyIndex === index ? { ...story, image, alt: file.name } : story))
  }

  return (
    <aside className="news-sidebar" aria-label="أخبار مختارة">
      <section className="sidebar-section">
        <h2 className="sidebar-heading"><Radio aria-hidden="true" /> آخر الأخبار</h2>
        <ol className="sidebar-list">
          {latestHeadlines.map((headline, index) => (
            <li key={headline}>
              <span className="sidebar-number">{formatArabicIndex(index)}</span>
              <Editable label="عنوان آخر الأخبار">{headline}</Editable>
            </li>
          ))}
        </ol>
      </section>
      <AdCreative
        variant="sidebar"
        initialImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Join%20for%20faceless%20income%20secrets%21%20%F0%9F%94%A5-4fxE7Vr5jHwE98qtxTVbeSQNSsaRhp.jpg"
        imageAlt="عرض للأجهزة الإلكترونية والمنزلية بخصم يصل إلى ٥٠٪"
        label="عرض الأجهزة الإلكترونية والمنزلية"
      />
      <section className="sidebar-section most-read-section">
        <h2 className="sidebar-heading"><ArrowUpLeft aria-hidden="true" /> الأكثر قراءة</h2>
        <ol className="sidebar-list sidebar-list--read">
          {mostReadHeadlines.map((headline, index) => (
            <li key={headline}>
              <span className="sidebar-number">{formatArabicIndex(index)}</span>
              <Editable label="عنوان الأكثر قراءة">{headline}</Editable>
            </li>
          ))}
        </ol>
      </section>
      <section className="sidebar-featured" aria-labelledby="sidebar-featured-heading">
        <h2 className="sidebar-heading" id="sidebar-featured-heading">أخبار جانبية</h2>
        <div className="sidebar-featured-list">
          {stories.map((story, index) => (
            <SidebarNewsCard key={index} story={story} index={index} onUpload={handleUpload} />
          ))}
        </div>
      </section>
    </aside>
  )
}

function Participation() {
  const [submitted, setSubmitted] = useState(false)
  const [opinion, setOpinion] = useState('')
  const [vote, setVote] = useState<string | null>(null)

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (opinion.trim()) setSubmitted(true)
  }

  return (
    <section className="participation-section" id="participate">
      <div className="participation-intro">
        <span className="participation-icon"><MessageSquareText aria-hidden="true" /></span>
        <span className="section-kicker">صوت القارئ</span>
        <h2>شارك برأيك</h2>
        <p>ما الأولوية التي تراها الأهم لتحسين الخدمات في منطقتك؟</p>
      </div>
      <div className="participation-content">
        <form className="opinion-form" onSubmit={handleSubmit}>
          <label htmlFor="reader-opinion">اكتب رأيك أو اقتراحك</label>
          <textarea
            id="reader-opinion"
            value={opinion}
            onChange={(event) => {
              setOpinion(event.target.value)
              setSubmitted(false)
            }}
            placeholder="نرحب بمشاركتك..."
            rows={3}
            required
          />
          <div className="form-footer">
            <span className="form-note">تُراجع المشاركات قبل النشر</span>
            <button className="submit-opinion" type="submit">
              إرسال الرأي <Send aria-hidden="true" />
            </button>
          </div>
          {submitted && <p className="form-success" role="status">شكراً لمشاركتك، وصلنا رأيك.</p>}
        </form>
        <fieldset className="reader-poll">
          <legend>استطلاع سريع</legend>
          <p>أي ملف تود متابعة أخباره أكثر؟</p>
          {['الخدمات المحلية', 'التعليم', 'النقل والمواصلات'].map((option) => (
            <button
              type="button"
              className={`poll-option ${vote === option ? 'poll-option--selected' : ''}`}
              aria-pressed={vote === option}
              key={option}
              onClick={() => setVote(option)}
            >
              <span className="poll-radio" aria-hidden="true" />
              {option}
            </button>
          ))}
          {vote && <span className="poll-thanks" role="status">تم تسجيل اختيارك: {vote}</span>}
        </fieldset>
      </div>
    </section>
  )
}

const editors = [
  'يحيى وائل على',
  'ملك محمد عرفات',
  'يوسف عماد فرغلي',
  'جنى طارق كمال',
  'ملك محمد رشيد',
]

function EditorialTeam() {
  const [photos, setPhotos] = useState<(string | null)[]>(Array(editors.length).fill(null))

  function handlePhotoUpload(index: number, event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    const nextPhoto = URL.createObjectURL(file)
    setPhotos((current) => current.map((photo, photoIndex) => photoIndex === index ? nextPhoto : photo))
  }

  return (
    <section className="team-section" aria-labelledby="team-title">
      <SectionHeading kicker="من يصنع الخبر" title="فريق التحرير" id="team-title" />
      <p className="team-note">اضغط على اسم المحرر لتحريره، أو اختر صورة للمحرر</p>
      <div className="team-grid">
        {editors.map((editor, index) => (
          <article className="editor-card" key={editor}>
            <label className="editor-photo" aria-label={`اختيار صورة المحرر ${index + 1}`}>
              <input
                className="visually-hidden"
                type="file"
                accept="image/*"
                aria-label={`اختيار صورة المحرر ${index + 1}`}
                onChange={(event) => handlePhotoUpload(index, event)}
              />
              {photos[index] ? (
                <Image src={photos[index] as string} alt="" fill sizes="54px" unoptimized />
              ) : (
                <UserRound aria-hidden="true" />
              )}
            </label>
            <Editable as="strong" className="editor-name" label={`ا��م المحرر ${index + 1}`}>
              {editor}
            </Editable>
          </article>
        ))}
      </div>
    </section>
  )
}

export default function NewspaperHome() {
  const [stories, setStories] = useState(initialStories)
  const [videoLinks, setVideoLinks] = useState([
    'https://share.google/2mpOV2nMxC2hb1JXk',
    'https://share.google/U43hC1DIkIeqxBMn1',
  ])

  function handleImageUpload(index: number, event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    const nextImage = URL.createObjectURL(file)
    setStories((current) => current.map((story, storyIndex) =>
      storyIndex === index ? { ...story, image: nextImage, alt: file.name } : story,
    ))
  }

  function handleVideoLinkChange(index: number, value: string) {
    setVideoLinks((current) => current.map((link, linkIndex) => linkIndex === index ? value : link))
  }

  return (
    <div className="newspaper" dir="rtl">
      <div className="utility-bar">
        <div className="page-container utility-inner">
          <span className="utility-date"><CalendarDays aria-hidden="true" /> الأربعاء، ٢٨ أكتوبر ٢٠٢٦</span>
          <span className="utility-motto">صحافة تقترب من الناس</span>
          <a href="#footer" className="utility-contact">اتصل بنا <ChevronLeft aria-hidden="true" /></a>
        </div>
      </div>

      <header className="masthead page-container">
        <a className="brand-lockup" href="#top" aria-label="من قلب الحدث - الرئيسية">
          <span className="brand-symbol" aria-hidden="true"><span /><span /><span /></span>
          <span className="brand-type">
            <span className="brand-name">من قلب الحدث</span>
            <span className="brand-tagline">صوت الشارع.. نبض الحقيقة</span>
          </span>
        </a>
        <div className="masthead-edition">
          <span>صحيفة مصرية مستقلة</span>
          <span>العدد اليومي · ٢٨ أكتوبر ٢٠٢٦</span>
        </div>
        <a className="masthead-link" href="#news">تصفح الأخبار <ArrowLeft aria-hidden="true" /></a>
      </header>

      <nav className="main-nav" aria-label="القائمة الرئيسية">
        <div className="page-container nav-inner">
          <a className="nav-home" href="#top" aria-label="الرئيسية"><Menu aria-hidden="true" /></a>
          <a className="nav-active" href="#news">الرئيسية</a>
          <a href="#news">مصر</a>
          <a href="#news">محافظات</a>
          <a href="#news">اقتصاد</a>
          <a href="#news">عرب وعالم</a>
          <a href="#news">ثقافة وفنون</a>
          <a href="#sidebar-featured-heading">رياضة</a>
          <a href="#videos">فيديو</a>
          <a href="#participate">شارك برأيك</a>
          <span className="nav-live"><span /> آخر الأخبار</span>
        </div>
      </nav>

      <div className="ticker-wrap">
        <div className="page-container ticker-inner">
          <span className="ticker-label"><span className="ticker-pulse" /> عاجل</span>
          <p><span>تغطية خاصة</span> — البرلمان المصري يوافق على تفويض الرئيس السيسي لدعم السعودية عسكريًا</p>
          <Clock3 aria-hidden="true" className="ticker-clock" />
        </div>
      </div>

      <main id="top" className="page-container main-content">
        <section className="lead-in article-lead" aria-label="عنوان الخبر">
          <div>
            <span className="lead-date">تغطية خاصة · الأربعاء ٢٨ أكتوبر ٢٠٢٦</span>
            <h1>البرلمان المصري يوافق على تفويض الرئيس السيسي لدعم السعودية عسكريًا</h1>
            <p>تفاصيل القرار البرلماني وخلفيته الدستورية وما يعنيه التفويض في ظل التوترات الإقليمية.</p>
          </div>
        </section>

        <div className="content-grid" id="news">
          <section className="news-feed" aria-labelledby="news-heading">
            <SectionHeading kicker="التفاصيل" title="تفاصيل القرار" id="news-heading" />
            <div className="story-list">
              {stories.map((story, index) => (
                <div key={index}>
                  <NewsStory story={story} index={index} onUpload={handleImageUpload} />
                  {index === 0 && (
                    <InlineVideoSection index={0} videoLink={videoLinks[0]} onLinkChange={handleVideoLinkChange} />
                  )}
                  {index === stories.length - 1 && (
                    <InlineVideoSection index={1} videoLink={videoLinks[1]} onLinkChange={handleVideoLinkChange} />
                  )}
                </div>
              ))}
            </div>
          </section>
          <NewsSidebar />
        </div>

        <AdCreative
          variant="banner"
          initialImage="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gadget%20Creative%20Cover%20Design-yUwfkNbSnTo1E1yvONVxVUEqLaCSrk.jpg"
          imageAlt="إعلان أفقي لأجهزة ذكية وسماعات وساعة وهاتف"
          label="عروض الأجهزة الذكية"
        />

        <section className="related-section" aria-labelledby="related-heading">
          <SectionHeading kicker="اقرأ أيضاً" title="موضوعات ذات صلة" id="related-heading" />
          <div className="related-grid">
            {[
              ['محافظات', 'خدمات جديدة تصل إلى عدد من المناطق خلال الأسابيع المقبلة'],
              ['مجتمع', 'مبادرات شبابية تفتح مساحات أوسع للعمل التطوعي'],
              ['تعليم', 'أنشطة مدرسية تعيد الاهتمام بالقراءة والعمل الجماعي'],
            ].map(([category, title], index) => (
              <a href="#news" className="related-card" key={title}>
                <span className="related-index">{formatArabicIndex(index)}</span>
                <span className="related-text"><span>{category}</span><Editable as="strong" label="عنوان موضوع ذي صلة">{title}</Editable></span>
                <ArrowUpLeft aria-hidden="true" />
              </a>
            ))}
          </div>
        </section>

        <Participation />
        <EditorialTeam />
      </main>

      <footer className="site-footer" id="footer">
        <div className="page-container footer-main">
          <div className="footer-about">
            <a className="footer-brand" href="#top">من قلب الحدث</a>
            <p>صحافة مصرية تتابع نبض الشارع، وتنقل الصورة كاملة بمهنية وموضوعية.</p>
          </div>
          <div className="footer-links">
            <h2>روابط سريعة</h2>
            <a href="#news">أخبار مصر</a><a href="#videos">فيديو</a><a href="#participate">شارك برأيك</a>
          </div>
          <div className="footer-links">
            <h2>تواصل معنا</h2>
            <a href="mailto:news@example.com">news@example.com</a><a href="#footer">سياسة النشر</a><a href="#footer">من نحن</a>
          </div>
          <div className="footer-social">
            <h2>تابعنا</h2>
            <div className="social-links">
              <a href="#footer" aria-label="موقعنا"><Globe2 aria-hidden="true" /></a>
              <a href="#footer" aria-label="قناتنا"><CirclePlay aria-hidden="true" /></a>
              <a href="#footer" aria-label="صورنا"><Camera aria-hidden="true" /></a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="page-container footer-bottom-inner">
            <span>© ٢٠٢٦ من قلب الحدث — جميع الحقوق محفوظة</span>
            <span>رأيكم يصنع فرقاً <CirclePlay aria-hidden="true" /></span>
          </div>
        </div>
      </footer>
    </div>
  )
}
